cnn2.py: for multi-class classification (abnormal vs normal)

cnn3.py: for multi-label classification (all diseases)
